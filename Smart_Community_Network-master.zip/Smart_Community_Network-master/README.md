# CMPE281
Cloud Computing Final Project 

## Environment setup
* Install python2.7
* Install python-pip
* Install the requirements of the project: pip install -r requirements.txt
* Install redis locally and change the host in the source code to localhost
* Run the app: python app.py
* The application will be running on localhost at port 3000

## Link to Running application:
http://community-221270452.us-east-1.elb.amazonaws.com/
